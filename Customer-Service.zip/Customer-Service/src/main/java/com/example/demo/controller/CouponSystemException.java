package com.example.demo.controller;

public class CouponSystemException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public CouponSystemException(String str)
	{
		System.out.println(str);
	}

}

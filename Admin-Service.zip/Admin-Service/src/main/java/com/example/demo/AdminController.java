package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AdminController {
	
	@Autowired
	private AdminService adminService;
	
	@RequestMapping("/user")
	public List<User> getAllUsers()
	{
		return adminService.getAllUsers();
	}
	
	/*@RequestMapping(method=RequestMethod.GET, value="/user/{id}")
	public User getUser(@PathVariable String id)
	{
		return adminService.getUser(id);
	}*/ 
	
	@RequestMapping(method=RequestMethod.POST, value="/user")
	public void addUser(@RequestBody User user)
	{
	   adminService.addUser(user);
	}
	
	@RequestMapping(method=RequestMethod.PUT, value="/user/{id}")
	public void UpdateUser(@RequestBody User user,@PathVariable String id)
	{
	   adminService.UpdateUser(id,user);
	}
	
	@RequestMapping(method=RequestMethod.DELETE, value="/user/{id}")
	public void deleteUser(@PathVariable String id)
	{
	   adminService.deleteUser(id);
	}
}

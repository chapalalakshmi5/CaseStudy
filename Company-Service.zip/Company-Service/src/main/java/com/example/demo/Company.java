package com.example.demo;

import java.util.ArrayList;
import java.util.List;


import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;



@Document(collection="product")
public class Company {
	
	
	@Id
	private int id;
	private  String comname;
	private List<Product> products;
   private Coupon coupon;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getComname() {
	return comname;
}
public void setComname(String comname) {
	this.comname = comname;
}
public List<Product> getProducts() {
	return products;
}
public void setProducts(List<Product> products) {
	this.products = products;
}
public Coupon getCoupon() {
	return coupon;
}
public void setCoupon(Coupon coupon) {
	this.coupon = coupon;
}
public Company(int id, String comname, List<Product> products, Coupon coupon) {
	super();
	this.id = id;
	this.comname = comname;
	this.products = products;
	this.coupon = coupon;
}
public Company() {
	
}
@Override
public String toString() {
	return "Company [id=" + id + ", comname=" + comname + ", products=" + products + ", coupon=" + coupon + "]";
}
	
}

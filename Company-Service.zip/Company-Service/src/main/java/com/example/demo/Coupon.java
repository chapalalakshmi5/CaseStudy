package com.example.demo;




public class Coupon {
	
	private int couponid;
	 private String code;
	 private  String discount;
	 private  String expDate;
	public int getCouponid() {
		return couponid;
	}
	public void setCouponid(int couponid) {
		this.couponid = couponid;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getDiscount() {
		return discount;
	}
	public void setDiscount(String discount) {
		this.discount = discount;
	}
	public String getExpDate() {
		return expDate;
	}
	public void setExpDate(String expDate) {
		this.expDate = expDate;
	}
	public Coupon(int couponid, String code, String discount, String expDate) {
		this.couponid = couponid;
		this.code = code;
		this.discount = discount;
		this.expDate = expDate;
	}
	public Coupon() {
		
	}
	@Override
	public String toString() {
		return "Coupon [couponid=" + couponid + ", code=" + code + ", discount=" + discount + ", expDate=" + expDate
				+ "]";
	}

	
	
	 

}

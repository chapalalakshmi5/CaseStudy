package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service
public class CompanyService{
	
	@Autowired
	private CompanyRepository companyRepository;
	
	public List<Company> getAllCompany()
	{
		List<Company> company=new ArrayList<>();
		companyRepository.findAll()
		.forEach(company::add);
		return company;
	}
	
	public void addCompany(Company company)

	{
		companyRepository.save(company);
	}
	public void UpdateCompany(int id, Company company) {
		companyRepository.save(company);
		
	}
	public void deleteCompany(int id) {
		companyRepository.deleteById(id);
		
	
	
}
}

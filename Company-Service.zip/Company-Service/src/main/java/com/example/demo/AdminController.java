package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;



@RestController
public class AdminController {
	
	@Autowired
	private  CompanyService companyService;
	
	@RequestMapping("/company")
	public List<Company> getAllCompany()
	{
		return companyService.getAllCompany();
	}
	
	/*@RequestMapping(method=RequestMethod.GET, value="/user/{id}")
	public User getUser(@PathVariable String id)
	{
		return adminService.getUser(id);
	}*/ 
	
	@RequestMapping(method=RequestMethod.POST, value="/company")
	public void addCompany(@RequestBody Company company)
	{
		companyService.addCompany(company);
	}
	
	@RequestMapping(method=RequestMethod.PUT, value="/company/{id}")
	public void UpdateCompany(@RequestBody Company company,@PathVariable int id)
	{
		companyService.UpdateCompany(id,company);
	}
	
	@RequestMapping(method=RequestMethod.DELETE, value="/company/{id}")
	public void deleteCompany(@PathVariable int id)
	{
		companyService.deleteCompany(id);
	}
}
